//
//  nearlistViewController.h
//  ailiao
//
//  Created by administrator on 16/3/31.
//  Copyright © 2016年 administrator. All rights reserved.
//

#import <RongIMKit/RongIMKit.h>

@interface nearlistViewController : RCConversationListViewController

@end
