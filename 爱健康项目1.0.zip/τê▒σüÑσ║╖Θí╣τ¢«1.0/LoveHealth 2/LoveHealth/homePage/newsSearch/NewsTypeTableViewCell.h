//
//  NewsTypeTableViewCell.h
//  搜索联想
//
//  Created by Administrator on 16/3/29.
//  Copyright © 2016年 Administrator. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsTypeTableViewCell : UITableViewCell

@property (strong,nonatomic)UIButton *btn;

@property (strong,nonatomic) UILabel *label;

@end
