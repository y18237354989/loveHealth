//
//  pageStructure.h
//  LoveHealth
//
//  Created by administrator on 16/3/26.
//  Copyright © 2016年 yjh. All rights reserved.
//

#ifndef pageStructure_h
#define pageStructure_h
/*
 1 首页>>
      1-1 新闻列表页
      1-2 新闻详情页
      1-3 新闻搜索页
 2 逛一逛>>
      2-1 商品推荐列表页
      2-2 商品单类列表页
      2-3 商品详情页
      2-4 在线客服页
      2-5 店铺页
 3 热贴>>
      3-1 热贴列表页
      3-2 热贴详情页
      3-3 发帖页
 4 我的>>
      4-1 主要功能列表页>>
         4-1-1 我的收藏页
         4-1-2 我的贴子页
         4-1-3 我的订单页
         4-1-4 我的购物车页
         4-1-5 意见反馈页
         4-1-6 设置页>>
                  个人资料页
                  关于页
      4-2 注册页
      4-3 登录页
      4-4 修改密码页
 */

#endif /* pageStructure_h */
