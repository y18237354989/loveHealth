//
//  GoodShopCollectionViewCell.h
//  逛一逛Tableview
//
//  Created by Administrator on 16/3/31.
//  Copyright © 2016年 Administrator. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodShopCollectionViewCell : UICollectionViewCell

@property (strong,nonatomic)UIImageView *goodsImage;

@property (strong,nonatomic)UILabel *goodsName;

@end
